Core/Src/bat.o: ../Core/Src/bat.c ../Core/Inc/bat.h
../Core/Inc/bat.h:
