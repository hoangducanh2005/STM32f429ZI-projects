#ifndef BAT_H
#define BAT_H

#include <stdint.h>

#define BAT_WIDTH   320
#define BAT_HEIGHT  240

extern const uint8_t bat_map[];

#endif
