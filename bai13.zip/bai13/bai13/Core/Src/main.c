/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Bai tap 13 - Dong ho so HH:MM:SS
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdio.h"
#include "string.h"

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
TIM_HandleTypeDef htim6;

// Biến lưu trữ thời gian
volatile uint8_t hours = 0, mins = 0, secs = 0, cent = 0;

// SỬA: Tăng kích thước buffer lên ít nhất 20 để tránh tràn bộ đệm
char lcd_buffer[32];

// THÊM: Khai báo lại biến này để các file irda.c và stm32f4xx_it.c không báo lỗi
volatile int tim6_count = 0;

/* USER CODE BEGIN PFP */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM6_Init(void);

// Hàm điều khiển LCD
void LCD_Write_8Bit(unsigned char x);
void LCD_Send_Command(unsigned char x);
void LCD_Write_One_Char(unsigned char c);
void LCD_Show_String(char *str);
void LCD_init(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define LCD_CTRL_PORT GPIOG
#define RW_PIN GPIO_PIN_2
#define RS_PIN GPIO_PIN_3
#define EN_PIN GPIO_PIN_4
#define LCD_DATA_PORT GPIOD

void LCD_Write_8Bit(unsigned char x) {
    LCD_DATA_PORT->ODR = (LCD_DATA_PORT->ODR & 0x00FF) | ((unsigned int)x << 8);
}

void LCD_Send_Command(unsigned char x) {
    LCD_Write_8Bit(x);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, RS_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, RW_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, EN_PIN, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, EN_PIN, GPIO_PIN_RESET);
    HAL_Delay(1);
}

void LCD_Write_One_Char(unsigned char c) {
    LCD_Write_8Bit(c);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, RS_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, RW_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, EN_PIN, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(LCD_CTRL_PORT, EN_PIN, GPIO_PIN_RESET);
    HAL_Delay(1);
}

void LCD_Show_String(char *str) {
    uint8_t i = 0;
    while (str[i] != '\0' && i < 16) {
        LCD_Write_One_Char(str[i]);
        i++;
    }
}

void LCD_init(void) {
    HAL_Delay(50);
    LCD_Send_Command(0x38); // 8-bit, 2 lines
    HAL_Delay(5);
    LCD_Send_Command(0x0C); // Display ON, Cursor OFF
    HAL_Delay(5);
    LCD_Send_Command(0x01); // Clear Display
    HAL_Delay(5);
}

// Callback ngắt Timer 6: Cập nhật thời gian mỗi giây
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM6) {
    	tim6_count++;
    	cent++;
    	if (cent >= 10) {
    		cent = 0;
    		secs++;
    		if (secs >= 60) {
    			secs = 0;
    		    mins++;
    		    if (mins >= 60) {
    		    	mins = 0;
    		        hours++;
    		        if (hours >= 24) {
    		        	hours = 0;
    		    	}
    			}
    		}
    	}
    }
}
/* USER CODE END 0 */

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM6_Init();
  MX_USART1_UART_Init();

  /* USER CODE BEGIN 2 */
  LCD_init();


  LCD_Send_Command(0x80); //mã 80 // Hiển thị tiêu đề cố định ở dòng 1
  LCD_Show_String(" DIGITAL CLOCK  ");

  // Bắt đầu Timer 6 ở chế độ ngắt
  HAL_TIM_Base_Start_IT(&htim6);
  /* USER CODE END 2 */

  while (1)
  {
    /* USER CODE BEGIN 3 */
    // Định dạng chuỗi thời gian HH:MM:SS
    sprintf(lcd_buffer, "   %02d:%02d:%02d:%01d   ", hours, mins, secs, cent);// đúng y nhiuw slideeee


    LCD_Send_Command(0xC0); // mã c0 // Hiển thị lên dòng 2 của LCD
    LCD_Show_String(lcd_buffer); // bên trên

    HAL_Delay(25); // Quét hiển thị sau mỗi 25ms
  }
    /* USER CODE END 3 */
}

static void MX_TIM6_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim6.Instance = TIM6;
  // Cấu hình để ngắt  (với Clock 90MHz)
  htim6.Init.Prescaler = 8999; // 10 000 count 1s => 1 count sau 0,1ms
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 999; // T = 0,1 x 1000 = 100ms = 0,1 s
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  // Khởi tạo chân Control (PG2, 3, 4)
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4, GPIO_PIN_RESET);
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  // Khởi tạo chân Data (PD8 - PD15)
  HAL_GPIO_WritePin(GPIOD, 0xFF00, GPIO_PIN_RESET);
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11| \
                        GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}

// Các hàm SystemClock_Config, MX_USART1_UART_Init và Error_Handler giữ nguyên...
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
