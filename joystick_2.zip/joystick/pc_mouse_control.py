import argparse
import ctypes
import re
import sys
import time
from ctypes import wintypes

import serial


DEFAULT_ADC_CENTER = 127
DEFAULT_DEADZONE = 10
MAX_ADC_DELTA = 128
JOYSTICK_SAMPLE_RATE = 20.0


if sys.platform.startswith("win"):
    ULONG_PTR = wintypes.WPARAM

    class Point(ctypes.Structure):
        _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

    class MouseInput(ctypes.Structure):
        _fields_ = [
            ("dx", wintypes.LONG),
            ("dy", wintypes.LONG),
            ("mouseData", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ULONG_PTR),
        ]

    class InputUnion(ctypes.Union):
        _fields_ = [("mi", MouseInput)]

    class Input(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("ii", InputUnion)]


def move_mouse_sendinput(dx, dy):
    mouse_input = MouseInput(dx, dy, 0, 0x0001, 0, 0)
    input_event = Input(0, InputUnion(mi=mouse_input))
    sent = ctypes.windll.user32.SendInput(1, ctypes.byref(input_event), ctypes.sizeof(input_event))
    return sent == 1


def move_mouse_setcursor(dx, dy):
    point = Point()
    if not ctypes.windll.user32.GetCursorPos(ctypes.byref(point)):
        return False
    return bool(ctypes.windll.user32.SetCursorPos(point.x + dx, point.y + dy))


def move_mouse_pyautogui(dx, dy):
    import pyautogui

    pyautogui.FAILSAFE = False
    pyautogui.PAUSE = 0
    pyautogui.moveRel(dx, dy, duration=0)


def move_mouse(dx, dy, backend):
    if sys.platform.startswith("win") and backend == "setcursor":
        return move_mouse_setcursor(dx, dy)

    if sys.platform.startswith("win") and backend == "sendinput":
        if move_mouse_sendinput(dx, dy):
            return True
        return move_mouse_setcursor(dx, dy)

    move_mouse_pyautogui(dx, dy)
    return True


def normalize_port(port):
    if sys.platform.startswith("win") and re.fullmatch(r"COM\d+", port.upper()):
        number = int(port[3:])
        if number >= 10:
            return rf"\\.\{port.upper()}"
    return port


def parse_joystick_line(line):
    values = [int(value) for value in re.findall(r"\d+", line)]
    if len(values) < 2:
        return None
    return values[0], values[1]


def axis_to_mouse_delta(value, center, deadzone, speed):
    diff = value - center
    if abs(diff) <= deadzone:
        return 0.0

    if diff > 0:
        diff -= deadzone
    else:
        diff += deadzone

    return (diff / MAX_ADC_DELTA) * speed


def read_joystick_sample(ser):
    raw = ser.readline().decode("ascii", errors="ignore").strip()
    if not raw:
        return None, raw
    return parse_joystick_line(raw), raw


def calibrate_center(ser, sample_count):
    xs = []
    ys = []
    print("Keep joystick at center for calibration...")

    while len(xs) < sample_count:
        data, _ = read_joystick_sample(ser)
        if data is None:
            continue
        xs.append(data[0])
        ys.append(data[1])

    center_x = sum(xs) // len(xs)
    center_y = sum(ys) // len(ys)
    print(f"Calibrated center: X={center_x}, Y={center_y}")
    return center_x, center_y


def test_mouse_backend(backend):
    print(f"Testing mouse backend: {backend}")
    for _ in range(20):
        move_mouse(15, 0, backend)
        time.sleep(0.02)
    for _ in range(20):
        move_mouse(-15, 0, backend)
        time.sleep(0.02)
    print("Mouse test finished.")


def main():
    parser = argparse.ArgumentParser(
        description="Receive joystick ADC data from STM32 USART1 and control the PC mouse."
    )
    parser.add_argument("port", help="Serial port, for example COM5")
    parser.add_argument("--baud", type=int, default=115200, help="UART baud rate")
    parser.add_argument("--speed", type=int, default=45, help="Maximum mouse step per reading")
    parser.add_argument("--mouse-rate", type=int, default=120, help="Mouse updates per second")
    parser.add_argument("--smooth", type=float, default=0.35, help="Smoothing factor from 0.05 to 1.0")
    parser.add_argument("--deadzone", type=int, default=DEFAULT_DEADZONE, help="ADC deadzone around center")
    parser.add_argument("--center-x", type=int, help="Manual X center value")
    parser.add_argument("--center-y", type=int, help="Manual Y center value")
    parser.add_argument("--calibrate-samples", type=int, default=20, help="Samples used for center calibration")
    parser.add_argument("--invert-x", action="store_true", help="Invert X axis direction")
    parser.add_argument("--invert-y", action="store_true", help="Invert Y axis direction")
    parser.add_argument("--debug", action="store_true", help="Print received ADC and mouse deltas")
    parser.add_argument(
        "--backend",
        choices=["sendinput", "setcursor", "pyautogui"],
        default="setcursor",
        help="Mouse movement backend",
    )
    parser.add_argument("--test-mouse", action="store_true", help="Move mouse left/right without opening serial")
    args = parser.parse_args()

    if args.test_mouse:
        test_mouse_backend(args.backend)
        return 0

    port = normalize_port(args.port)

    try:
        with serial.Serial(port, args.baud, timeout=1) as ser:
            print(f"Listening on {args.port} at {args.baud} baud. Press Ctrl+C to stop.")
            print("Close Hercules before running this script because only one app can open a COM port.")
            time.sleep(2)
            ser.reset_input_buffer()

            if args.center_x is None or args.center_y is None:
                center_x, center_y = calibrate_center(ser, args.calibrate_samples)
            else:
                center_x = args.center_x
                center_y = args.center_y

            ser.timeout = 0.001
            mouse_interval = 1.0 / args.mouse_rate
            smooth = max(0.05, min(args.smooth, 1.0))
            target_dx = 0.0
            target_dy = 0.0
            current_dx = 0.0
            current_dy = 0.0
            x_accum = 0.0
            y_accum = 0.0
            next_mouse_tick = time.perf_counter()

            while True:
                data, raw = read_joystick_sample(ser)
                if data is not None:
                    x_value, y_value = data
                    target_dx = axis_to_mouse_delta(x_value, center_x, args.deadzone, args.speed)
                    target_dy = axis_to_mouse_delta(y_value, center_y, args.deadzone, args.speed)

                    if args.invert_x:
                        target_dx = -target_dx
                    if args.invert_y:
                        target_dy = -target_dy

                    if args.debug:
                        print(f"{raw} -> target dx={target_dx:.2f}, dy={target_dy:.2f}")

                now = time.perf_counter()
                if now < next_mouse_tick:
                    time.sleep(min(next_mouse_tick - now, 0.002))
                    continue

                next_mouse_tick += mouse_interval
                if next_mouse_tick < now - mouse_interval:
                    next_mouse_tick = now + mouse_interval

                current_dx += (target_dx - current_dx) * smooth
                current_dy += (target_dy - current_dy) * smooth

                x_accum += current_dx * (JOYSTICK_SAMPLE_RATE / args.mouse_rate)
                y_accum += current_dy * (JOYSTICK_SAMPLE_RATE / args.mouse_rate)

                dx = int(x_accum)
                dy = int(y_accum)

                if dx != 0:
                    x_accum -= dx
                if dy != 0:
                    y_accum -= dy

                if dx or dy:
                    moved = move_mouse(dx, dy, args.backend)
                    if args.debug and not moved:
                        print("Mouse move failed")

    except serial.SerialException as exc:
        print(f"Serial error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nStopped.")
        return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
