/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Bai tap 3 - STM32F429 + I3G4250D/L3GD20
  *
  * Chuc nang:
  * - Doc gia toc goc AngleX, AngleY, AngleZ tu cam bien I3G4250D/L3GD20
  * - Gui X, Y, Z len PC qua USART1 de xem bang Hercules
  * - Dieu khien LED:
  *     AngleX > 0  -> bat LED3 PG13
  *     AngleY > 0  -> bat LED4 PG14
  *     AngleZ > 0  -> bat ca LED3 va LED4
  *
  * Cau hinh CubeMX:
  * - SYSCLK = 180 MHz
  * - SPI5 Full-Duplex Master
  *   PF7 = SPI5_SCK
  *   PF8 = SPI5_MISO
  *   PF9 = SPI5_MOSI
  *   PC1 = GPIO_Output, CS cua L3GD20
  * - USART1 Asynchronous 115200 8N1
  *   PA9  = USART1_TX
  *   PA10 = USART1_RX
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"

/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "l3gd20.h"
/* USER CODE END Includes */

SPI_HandleTypeDef hspi5;
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
char uart_buf[120];

float AngleX = 0.0f;
float AngleY = 0.0f;
float AngleZ = 0.0f;
/* USER CODE END PV */

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI5_Init(void);
static void MX_USART1_UART_Init(void);

/* USER CODE BEGIN PFP */
static void UART_SendString(char *str);
static void UART_SendXYZ(float x, float y, float z);
static void Float_To_String_3(char *out, float value);
static void LED_Update(float x, float y, float z);
/* USER CODE END PFP */

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_SPI5_Init();
  MX_USART1_UART_Init();

  /* USER CODE BEGIN 2 */
  UART_SendString("\r\n===== STM32F429 + L3GD20/I3G4250D =====\r\n");

  /*
   * Ham khoi tao cam bien.
   * Neu thu vien cua thay dat ten khac, sua dong nay theo file .h.
   */
  L3GD20_Init();

  UART_SendString("Gyroscope init done.\r\n\r\n");
  /* USER CODE END 2 */

  while (1)
  {
    /* USER CODE BEGIN WHILE */

    /*
     * Mot so thu vien can goi L3GD20_LOOP() truoc khi lay gia tri.
     * Neu thu vien cua ban khong co ham nay, hay comment dong duoi.
     */
    L3GD20_loop();

    AngleX = get_Angle_X();
    AngleY = get_Angle_Y();
    AngleZ = get_Angle_Z();

    UART_SendXYZ(AngleX, AngleY, AngleZ);
    LED_Update(AngleX, AngleY, AngleZ);

    HAL_Delay(300);

    /* USER CODE END WHILE */
  }
}

/* USER CODE BEGIN 4 */

static void UART_SendString(char *str)
{
  HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), HAL_MAX_DELAY);
}

/*
 * Chuyen float thanh chuoi co 3 chu so sau dau cham.
 * Lam cach nay de tranh loi printf khong in duoc %f tren STM32CubeIDE.
 */
static void Float_To_String_3(char *out, float value)
{
  int sign = 0;
  int32_t int_part;
  int32_t frac_part;
  float temp;

  if (value < 0.0f)
  {
    sign = 1;
    value = -value;
  }

  int_part = (int32_t)value;
  temp = value - (float)int_part;
  frac_part = (int32_t)(temp * 1000.0f + 0.5f);

  if (frac_part >= 1000)
  {
    int_part++;
    frac_part -= 1000;
  }

  if (sign)
  {
    sprintf(out, "-%ld.%03ld", (long)int_part, (long)frac_part);
  }
  else
  {
    sprintf(out, "%ld.%03ld", (long)int_part, (long)frac_part);
  }
}

static void UART_SendXYZ(float x, float y, float z)
{
  char sx[20], sy[20], sz[20];

  Float_To_String_3(sx, x);
  Float_To_String_3(sy, y);
  Float_To_String_3(sz, z);

  sprintf(uart_buf, "X = %s, Y = %s, Z = %s\r\n", sx, sy, sz);
  HAL_UART_Transmit(&huart1, (uint8_t *)uart_buf, strlen(uart_buf), HAL_MAX_DELAY);
}

static void LED_Update(float x, float y, float z)
{
  if (z > 0.0f)
  {
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_SET);
  }
  else
  {
    if (x > 0.0f)
    {
      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET);
    }
    else
    {
      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET);
    }

    if (y > 0.0f)
    {
      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_SET);
    }
    else
    {
      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET);
    }
  }
}

/* USER CODE END 4 */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;

  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 360;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK  |
                                RCC_CLOCKTYPE_SYSCLK |
                                RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;

  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_SPI5_Init(void)
{
  hspi5.Instance = SPI5;
  hspi5.Init.Mode = SPI_MODE_MASTER;
  hspi5.Init.Direction = SPI_DIRECTION_2LINES;
  hspi5.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi5.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi5.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi5.Init.NSS = SPI_NSS_SOFT;
  hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi5.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi5.Init.CRCPolynomial = 10;

  if (HAL_SPI_Init(&hspi5) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;

  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  // PC1: CS cua cam bien L3GD20/I3G4250D
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);

  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  // PG13, PG14: LED3, LED4
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13 | GPIO_PIN_14, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = GPIO_PIN_13 | GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
}

void Error_Handler(void)
{
  __disable_irq();

  while (1)
  {
    HAL_GPIO_TogglePin(GPIOG, GPIO_PIN_14);
    HAL_Delay(200);
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
